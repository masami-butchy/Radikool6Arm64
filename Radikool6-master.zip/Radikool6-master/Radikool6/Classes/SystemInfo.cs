﻿namespace Radikool6.Classes
{
    public class SystemInfo
    {
        public string Version { get; } = "6.0-alpha(20180511)";
    }
}