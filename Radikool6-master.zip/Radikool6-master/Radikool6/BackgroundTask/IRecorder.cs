﻿using System.Threading.Tasks;

namespace Radikool6.BackgroundTask
{
    public interface IRecorder
    {
        Task Start();
    }
}