export interface ReserveTask {
  id?: string;
  start?: Date;
  end?: Date;
  status?: string;

}
