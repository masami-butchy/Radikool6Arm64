export interface SystemInfo {
  version?: string;
}
