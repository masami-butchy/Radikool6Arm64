﻿using System.Security.Cryptography.X509Certificates;
using Microsoft.AspNetCore.Mvc;
using Radikool6.Entities;


namespace Radikool6.Controllers
{
    public class HomeController : BaseController
    {

        public HomeController()
        {
            
        }

    }
}
